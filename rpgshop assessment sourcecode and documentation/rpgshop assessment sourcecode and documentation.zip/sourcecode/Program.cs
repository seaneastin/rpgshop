﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rpgshop_assessment_intro_to_c_sharp
{
    class Program
    {

        static void Main(string[] args)
        {
               Game game = new Game(); //creates a new instance of the game
            game.start(); // goes to set up all the weapons 
        }

    }
}
