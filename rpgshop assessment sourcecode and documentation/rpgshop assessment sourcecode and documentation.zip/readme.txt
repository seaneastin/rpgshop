to launch this program please open the exe file and use the keyboard to control the game

to enter the superuser menu type 484 on the menu